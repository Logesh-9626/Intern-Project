import React from "react";

const FileAnswer=()=>{

    return(
<div>
<div className="container" > 
            <div className="container d-flex justify-content-center mt-3 h-50 mb-2  shadow-lg p-3 mt-3 border-0  " >
           <h4
           style={{
            height:"100px",
           textAlign:"center",
            overflow:"auto"
           }}> </h4>
           <buttton className="btn btn-primary">Submit</buttton>

          </div>

    </div>
</div>
    )
}

export default FileAnswer;